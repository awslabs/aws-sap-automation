#!/bin/sh

home_dir="/root/install"
s4h_faa_dir="$home_dir/s4h_faa"
post_deploy_log="$home_dir/post_deploy.log"

echo " " >> $post_deploy_log

echo "$(date +%Y-%m-%d_%H:%M:%S)......Calibrating """/hana/data""" """/hana/log""" and """/media""" for storage and performance" >> $post_deploy_log

TOKEN=$(curl -s -X PUT "http://169.254.169.254/latest/api/token" -H "X-aws-ec2-metadata-token-ttl-seconds: 300")

ec2_instance_id=$(curl -s -H "X-aws-ec2-metadata-token: $TOKEN" http://169.254.169.254/latest/meta-data/instance-id)

ec2_az=$(curl -s -H "X-aws-ec2-metadata-token: $TOKEN" http://169.254.169.254/latest/meta-data/placement/availability-zone)

ec2_region=${ec2_az::-1}

media_volume_id="`aws ec2 describe-volumes  --filters Name=attachment.device,Values=/dev/sdz Name=attachment.instance-id,Values=$ec2_instance_id --query 'Volumes[*].{ID:VolumeId}' --region $ec2_region --output text`"

data_volume_id="`aws ec2 describe-volumes  --filters Name=attachment.device,Values=/dev/sdl Name=attachment.instance-id,Values=$ec2_instance_id --query 'Volumes[*].{ID:VolumeId}' --region $ec2_region --output text`"

log_volume_id="`aws ec2 describe-volumes  --filters Name=attachment.device,Values=/dev/sdt Name=attachment.instance-id,Values=$ec2_instance_id --query 'Volumes[*].{ID:VolumeId}' --region $ec2_region --output text`"

data_volume="${data_volume_id//-}"
log_volume="${log_volume_id//-}"

data_nvme_pv="$(nvme list | grep ${data_volume} | awk '{print $1}')"
log_nvme_pv="$(nvme list | grep ${log_volume} | awk '{print $1}')"

aws ec2 modify-volume --iops 16000 --throughput 1000 --size 500 --volume-id $media_volume_id --region ec2_region
aws ec2 modify-volume --iops 16000 --throughput 1000 --size 500 --volume-id $data_volume_id --region ec2_region
aws ec2 modify-volume --iops 16000 --throughput 1000 --size 128 --volume-id $log_volume_id --region ec2_region

sleep 10

xfs_growfs -d /media

pvresize $data_nvme_pv
lvextend --resizefs -l +100%FREE /dev/$(pvs | grep ${data_nvme_pv} | awk '{print $2}')/$(lvs | grep $(pvs | grep ${data_nvme_pv} | awk '{print $2}') | awk '{print $1}')

pvresize $log_nvme_pv
lvextend --resizefs -l +100%FREE /dev/$(pvs | grep ${log_nvme_pv} | awk '{print $2}')/$(lvs | grep $(pvs | grep ${log_nvme_pv} | awk '{print $2}') | awk '{print $1}')


echo "$(date +%Y-%m-%d_%H:%M:%S)......Creating media directories..." >> $post_deploy_log

mkdir -p /media/compressed /media/extracted/hana /media/extracted/swpm

cd /media/compressed

echo "$(date +%Y-%m-%d_%H:%M:%S)......Copying exports .ZIP files from $1" >> $post_deploy_log
aws s3 cp $1/ exports --recursive

echo "$(date +%Y-%m-%d_%H:%M:%S)......Copying SWPM .SAR file from $2" >> $post_deploy_log
aws s3 cp $2/ swpm --recursive

chmod -R 775 /media

cd exports

echo "$(date +%Y-%m-%d_%H:%M:%S)......Media downloaded. Extracting files..." >> $post_deploy_log

unzip -o \*.ZIP -d /media/extracted/hana

rm -r *

echo "$(date +%Y-%m-%d_%H:%M:%S)......Moving extracted media files..." >> $post_deploy_log

cd ../../extracted/hana

mv SAPS4HANA2023FPS00SAPHANADB20_2/*.tgz-* SAPS4HANA2023FPS00SAPHANADB20_1

mv SAPS4HANA2023FPS00SAPHANADB20_3/*.tgz-* SAPS4HANA2023FPS00SAPHANADB20_1

mv SAPS4HANA2023FPS00SAPHANADB20_4/*.tgz-* SAPS4HANA2023FPS00SAPHANADB20_1

cd SAPS4HANA2023FPS00SAPHANADB20_1

echo "$(date +%Y-%m-%d_%H:%M:%S)......Expanding /hana/shared .tgz files" >> $post_deploy_log

cat dbexe.tgz-* | tar -zpxvf - -C /

echo "$(date +%Y-%m-%d_%H:%M:%S)......Expanding /hana/data .tgz files" >> $post_deploy_log

cat dbdata.tgz-* | tar -zpxvf - -C /

echo "$(date +%Y-%m-%d_%H:%M:%S)......Expanding /hana/log .tgz files" >> $post_deploy_log

cat dblog.tgz-* | tar -zpxvf - -C /

echo "$(date +%Y-%m-%d_%H:%M:%S)......Expanding /usr/sap .tgz files" >> $post_deploy_log

cat usrsap_s4h.tgz-* | tar -zpxvf - -C /

echo "$(date +%Y-%m-%d_%H:%M:%S)......Expanding /sapmnt .tgz files" >> $post_deploy_log

cat sapmnt_s4h.tgz-* | tar -zpxvf - -C /

echo "$(date +%Y-%m-%d_%H:%M:%S)......File expansion complete..." >> $post_deploy_log

echo "$(date +%Y-%m-%d_%H:%M:%S)......Verifying gid for sapsys and set to 1000 if not already" >> $post_deploy_log

groupmod -g 1000 sapsys
sed -i "s/sapci/$HOSTNAME/g" $s4h_faa_dir/hana_config.cfg

echo "$(date +%Y-%m-%d_%H:%M:%S)......Running hdblcm to register system..." >> $post_deploy_log

cat $s4h_faa_dir/hana_passwords.xml | /hana/shared/HDB/hdblcm/hdblcm --batch --action=register_rename_system --read_password_from_stdin=xml --configfile=$s4h_faa_dir/hana_config.cfg

echo "$(date +%Y-%m-%d_%H:%M:%S)......Verifying HANA OS processes..." >> $post_deploy_log

echo " " >> $post_deploy_log

echo $(/usr/sap/hostctrl/exe/sapcontrol -nr 02 -function GetProcessList) >> $post_deploy_log

echo " " >> $post_deploy_log

echo "$(date +%Y-%m-%d_%H:%M:%S)......HANA database successfully configured..." >> $post_deploy_log

echo "$(date +%Y-%m-%d_%H:%M:%S)......Extracting SWPM for configuring application server..." >> $post_deploy_log

cd ../../swpm

/sapmnt/S4H/exe/uc/linuxx86_64/SAPCAR -xvf /media/compressed/swpm/*SAR

sed -i "s/vhcalhdbdb/$HOSTNAME/g" /sapmnt/S4H/profile/DEFAULT.PFL
sed -i "s/saps4hfaa/$HOSTNAME/g" $s4h_faa_dir/inifile.params

echo "$(date +%Y-%m-%d_%H:%M:%S)......Executing sapinst..." >> $post_deploy_log

./sapinst SAPINST_SLP_MODE=false SAPINST_EXECUTE_PRODUCT_ID=NW_StorageBasedCopy SAPINST_INPUT_PARAMETERS_URL=${s4h_faa_dir}/inifile.params SAPINST_SKIP_DIALOGS=true -nogui -noguiserver

echo "$(date +%Y-%m-%d_%H:%M:%S)......sapinst process finished..." >> $post_deploy_log

echo "$(date +%Y-%m-%d_%H:%M:%S)......Starting SAP services" >> $post_deploy_log

su - s4hadm -c "sapcontrol -nr 01 -function Start"

su - s4hadm -c "sapcontrol -nr 00 -function Start"

echo " " >> $post_deploy_log

echo "$(date +%Y-%m-%d_%H:%M:%S)......Fetching SAP service status for ASCS" >> $post_deploy_log

echo " " >> $post_deploy_log

echo $(/usr/sap/hostctrl/exe/sapcontrol -nr 01 -function GetProcessList) >> $post_deploy_log

echo " " >> $post_deploy_log

echo "$(date +%Y-%m-%d_%H:%M:%S)......Fetching SAP service status for Dialog Server" >> $post_deploy_log

echo " " >> $post_deploy_log

sleep 15

echo $(/usr/sap/hostctrl/exe/sapcontrol -nr 00 -function GetProcessList) >> $post_deploy_log

echo " " >> $post_deploy_log

echo "$(date +%Y-%m-%d_%H:%M:%S)......Executing cleanup..." >> $post_deploy_log

rm -r /media/compressed
rm -r /media/extracted
rm -r $s4h_faa_dir

echo "$(date +%Y-%m-%d_%H:%M:%S)......Cleanup complete..." >> $post_deploy_log

echo " " >> $post_deploy_log

echo "---------- SAP System Details ----------" >> $post_deploy_log
echo "HANA SID - HDB" >> $post_deploy_log
echo "HANA Instance No. - 02" >> $post_deploy_log
echo "Application SID - S4H" >> $post_deploy_log
echo "ASCS Instance No. - 01" >> $post_deploy_log
echo "Dialog Instance No. - 00" >> $post_deploy_log
echo "Master Password - Final_1234" >> $post_deploy_log
echo "----------------------------------------" >> $post_deploy_log

echo " " >> $post_deploy_log

echo "SAP S/4HANA FAA system successfully installed" >> $post_deploy_log

echo " " >> $post_deploy_log