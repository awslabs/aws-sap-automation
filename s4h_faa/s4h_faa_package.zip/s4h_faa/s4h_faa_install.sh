#!/bin/sh

# version - 2.0

home_dir="/root/install"
s4h_faa_dir="$home_dir/s4h_faa"
post_deploy_log="$home_dir/post_deploy.log"

red=$'\033[1;31m'
green=$'\033[1;32m'
yellow=$'\033[1;33m'
bggray=$'\033[1;48m'
nc=$'\033[0m'

s4h_faa_exports=$1
s4h_swpm=$2
s4h_version=$3

cleanup () {
	echo " " >> $post_deploy_log
	echo "$(date +%Y-%m-%d_%H:%M:%S)......Performing cleanup..." >> $post_deploy_log
	rm -r /media/compressed
	rm -r /media/extracted
	rm -r $s4h_faa_dir
}

log () {
	echo " " >> $post_deploy_log
	echo "$(date +%Y-%m-%d_%H:%M:%S)......$1" >> $post_deploy_log
}

error () {
	echo " " >> $post_deploy_log
	echo "${red}$1${nc}" >> $post_deploy_log
	echo " " >> $post_deploy_log
	echo "$2" >> $post_deploy_log
	cleanup
	echo " " >> $post_deploy_log
	echo "$(date +%Y-%m-%d_%H:%M:%S)......${red}SAP S/4HANA FAA $s4h_version system deployment ended with error. Please check the log above for more details...${nc}" >> $post_deploy_log
	exit 1
}

if [ "$s4h_faa_exports" = "" ]; then
	error "Parameter ""s4h_faa_exports"" is missing"
else
	log "Parameter ""s4h_faa_exports"" set as $s4h_faa_exports"
fi

if [ "$s4h_swpm" = "" ]; then
	error "Parameter ""s4h_swpm"" is missing"
else
	log "Parameter ""s4h_swpm"" set as $s4h_swpm"
fi

if [ "$s4h_version" = "" ]; then
	error "Parameter ""s4h_version"" is missing"
else
	case "$s4h_version" in

		"2023_FPS00" | "2023_FPS02")
			log "Parameter ""s4h_version"" set as $s4h_version"
			;;

		*)
			error """s4h_version"" $s4h_version not supported"
			;;
	esac
fi

log "Calibrating """/hana/data""" """/hana/log""" and """/media""" for storage and performance"

TOKEN=$(curl -s -X PUT "http://169.254.169.254/latest/api/token" -H "X-aws-ec2-metadata-token-ttl-seconds: 300")

ec2_instance_id=$(curl -s -H "X-aws-ec2-metadata-token: $TOKEN" http://169.254.169.254/latest/meta-data/instance-id)

ec2_az=$(curl -s -H "X-aws-ec2-metadata-token: $TOKEN" http://169.254.169.254/latest/meta-data/placement/availability-zone)

ec2_region=${ec2_az::-1}

media_volume_id="`aws ec2 describe-volumes  --filters Name=attachment.device,Values=/dev/sdz Name=attachment.instance-id,Values=$ec2_instance_id --query 'Volumes[*].{ID:VolumeId}' --region $ec2_region --output text`"

data_volume_id="`aws ec2 describe-volumes  --filters Name=attachment.device,Values=/dev/sdl Name=attachment.instance-id,Values=$ec2_instance_id --query 'Volumes[*].{ID:VolumeId}' --region $ec2_region --output text`"

log_volume_id="`aws ec2 describe-volumes  --filters Name=attachment.device,Values=/dev/sdt Name=attachment.instance-id,Values=$ec2_instance_id --query 'Volumes[*].{ID:VolumeId}' --region $ec2_region --output text`"

data_volume="${data_volume_id//-}"
log_volume="${log_volume_id//-}"

data_nvme_pv="$(nvme list | grep ${data_volume} | awk '{print $1}')"
log_nvme_pv="$(nvme list | grep ${log_volume} | awk '{print $1}')"

command_output=$(aws ec2 modify-volume --iops 16000 --throughput 1000 --size 500 --volume-id $media_volume_id --region $ec2_region --output json 2>&1)
if [ $? -ne 0 ]; then
	error "Error in modifying ""/media"" EC2 volume...." "$command_output"
else
	command_output=""
fi

command_output=$(aws ec2 modify-volume --iops 16000 --throughput 1000 --size 500 --volume-id $data_volume_id --region $ec2_region --output json 2>&1)
if [ $? -ne 0 ]; then
	error "Error in modifying ""/hana/data"" EC2 volume...." "$command_output"
else
	command_output=""
fi

command_output=$(aws ec2 modify-volume --iops 16000 --throughput 1000 --size 128 --volume-id $log_volume_id --region $ec2_region --output json 2>&1)
if [ $? -ne 0 ]; then
	error "Error in modifying ""/hana/log"" EC2 volume...." "$command_output"
else
	command_output=""
fi

sleep 10

command_output=$(xfs_growfs -d /media 2>&1)
if [ $? -ne 0 ]; then
	error "Error in extending ""/media"" filesystem...." "$command_output"
else
	command_output=""
fi

pvresize $data_nvme_pv
command_output=$(lvextend --resizefs -l +100%FREE /dev/$(pvs | grep ${data_nvme_pv} | awk '{print $2}')/$(lvs | grep $(pvs | grep ${data_nvme_pv} | awk '{print $2}') | awk '{print $1}') 2>&1)
if [ $? -ne 0 ]; then
	error "Error in extending ""/hana/data"" filesystem...." "$command_output"
else
	command_output=""
fi

pvresize $log_nvme_pv
command_output=$(lvextend --resizefs -l +100%FREE /dev/$(pvs | grep ${log_nvme_pv} | awk '{print $2}')/$(lvs | grep $(pvs | grep ${log_nvme_pv} | awk '{print $2}') | awk '{print $1}') 2>&1)
if [ $? -ne 0 ]; then
	error "Error in extending ""/hana/log"" filesystem...." "$command_output"
else
	command_output=""
fi

log "Creating media directories..."

mkdir -p /media/compressed /media/extracted/hana /media/extracted/swpm

cd /media/compressed

log "Copying exports .ZIP files from s4h_faa_exports"
command_output=$(aws s3 cp $s4h_faa_exports/ exports --recursive --output json 2>&1)
if [ $? -ne 0 ]; then
	error "Error downloading S/4HANA FAA export files from S3 bucket...." "$command_output"
else
	command_output=""
fi

log "Copying SWPM .SAR file from s4h_swpm"
command_output=$(aws s3 cp $s4h_swpm/ swpm --recursive --output json 2>&1)
if [ $? -ne 0 ]; then
	error "Error downloading SWPM from S3 bucket...." "$command_output"
else
	command_output=""
fi

chmod -R 775 /media
cd exports

log "Media downloaded. Extracting files..."
command_output=$(unzip -o \*.ZIP -d /media/extracted/hana 2>&1)
if [ $? -ne 0 ]; then
	error "Error in extracting ZIP files...." "$command_output"
else
	command_output=""
fi

rm -r *

log "Moving extracted media files..."

cd ../../extracted/hana

case "$s4h_version" in

	"2023_FPS00")
		default_password=$(cat SAPS4HANA2023FPS00SAPHANADB20_4/sapinst.txt | grep masterPassword | awk -F'=' '{print $2}')
		if [ $? -ne 0 ]; then
			error "Error in extracting default SAP password...." "$command_output"
		fi
		mv SAPS4HANA2023FPS00SAPHANADB20_2/*.tgz-* SAPS4HANA2023FPS00SAPHANADB20_1
		mv SAPS4HANA2023FPS00SAPHANADB20_3/*.tgz-* SAPS4HANA2023FPS00SAPHANADB20_1
		mv SAPS4HANA2023FPS00SAPHANADB20_4/*.tgz-* SAPS4HANA2023FPS00SAPHANADB20_1
		cd SAPS4HANA2023FPS00SAPHANADB20_1
		;;

	"2023_FPS02")
		default_password=$(cat SAPS4HANA2023FPS02SAPHANADB20_5/sapinst.txt | grep masterPassword | awk -F'=' '{print $2}')
		if [ $? -ne 0 ]; then
			error "Error in extracting default SAP password...." "$command_output"
		fi
		mv SAPS4HANA2023FPS02SAPHANADB20_2/*.tgz-* SAPS4HANA2023FPS02SAPHANADB20_1
		mv SAPS4HANA2023FPS02SAPHANADB20_3/*.tgz-* SAPS4HANA2023FPS02SAPHANADB20_1
		mv SAPS4HANA2023FPS02SAPHANADB20_4/*.tgz-* SAPS4HANA2023FPS02SAPHANADB20_1
		mv SAPS4HANA2023FPS02SAPHANADB20_5/*.tgz-* SAPS4HANA2023FPS02SAPHANADB20_1
		cd SAPS4HANA2023FPS02SAPHANADB20_1
		;;

	*)
		error "Internal error"
		;;
esac

if [ "$default_password" = "" ]; then
	error "Error in extracting default SAP password...."
fi

log "Expanding /hana/shared .tgz files"
cat dbexe.tgz-* | tar -zpxvf - -C /

log "Expanding /hana/data .tgz files"
cat dbdata.tgz-* | tar -zpxvf - -C /

log "Expanding /hana/log .tgz files"
cat dblog.tgz-* | tar -zpxvf - -C /

log "Expanding /usr/sap .tgz files"
cat usrsap_s4h.tgz-* | tar -zpxvf - -C /

log "Expanding /sapmnt .tgz files"
cat sapmnt_s4h.tgz-* | tar -zpxvf - -C /

log "File expansion complete..."

log "Verifying gid for sapsys"

command_output=$(groupmod -g 1000 sapsys 2>&1)
if [ $? -ne 0 ]; then
	log "Could not attach group id 1000 to sapsys...." "$command_output"
else
	command_output=""
fi

sed -i "s/sapci/$HOSTNAME/g" $s4h_faa_dir/hana_config.cfg
sed -i "s/{PASSWORD}/$default_password/g" $s4h_faa_dir/hana_passwords.xml

log "Registering HANA database..."

command_output=$(cat $s4h_faa_dir/hana_passwords.xml | /hana/shared/HDB/hdblcm/hdblcm --batch --action=register_rename_system --read_password_from_stdin=xml --configfile=$s4h_faa_dir/hana_config.cfg 2>&1)
if [ $? -ne 0 ]; then
	error "SAP HANA registration process resulted in error...." "$command_output"
else
	command_output=""
fi

log "Verifying HANA OS processes..."

echo " " >> $post_deploy_log
echo $(/usr/sap/hostctrl/exe/sapcontrol -nr 02 -function GetProcessList) >> $post_deploy_log

log "Finished registering HANA database..."
log "Extracting SWPM for configuring application server..."

cd ../../swpm

command_output=$(/sapmnt/S4H/exe/uc/linuxx86_64/SAPCAR -xvf /media/compressed/swpm/*SAR 2>&1)
if [ $? -ne 0 ]; then
	error "Error extracting SWPM software...." "$command_output"
else
	command_output=""
fi

sed -i "s/vhcalhdbdb/$HOSTNAME/g" /sapmnt/S4H/profile/DEFAULT.PFL
sed -i "s/saps4hfaa/$HOSTNAME/g" $s4h_faa_dir/inifile.params
sed -i "s/{PASSWORD}/$default_password/g" $s4h_faa_dir/inifile.params

log "Executing sapinst..."

command_output=$(./sapinst SAPINST_SLP_MODE=false SAPINST_EXECUTE_PRODUCT_ID=NW_StorageBasedCopy SAPINST_INPUT_PARAMETERS_URL=${s4h_faa_dir}/inifile.params SAPINST_SKIP_DIALOGS=true -nogui -noguiserver 2>&1)
if [ $? -ne 0 ]; then
	error "SAP Application server installation process resulted in error...." "$command_output"
else
	command_output=""
fi

log "sapinst process finished..."
log "Starting SAP services"

su - s4hadm -c "sapcontrol -nr 01 -function Start"
if [ $? -ne 0 ]; then
	log "${yellow}sapinst process finished but ASCS couldn't be started. Please try starting the process manually after installation finishes...${nc}"
fi

su - s4hadm -c "sapcontrol -nr 00 -function Start"
if [ $? -ne 0 ]; then
	log "${yellow}sapinst process finished but dialog server couldn't be started. Please try starting the process manually after installation finishes...${nc}"
fi

log "Fetching SAP service status for ASCS"
echo " " >> $post_deploy_log
echo $(/usr/sap/hostctrl/exe/sapcontrol -nr 01 -function GetProcessList) >> $post_deploy_log

log "Fetching SAP service status for Dialog Server"
echo " " >> $post_deploy_log
sleep 15
echo $(/usr/sap/hostctrl/exe/sapcontrol -nr 00 -function GetProcessList) >> $post_deploy_log
echo " " >> $post_deploy_log

echo "${bggray}---------- SAP System Details ----------" >> $post_deploy_log
echo "HANA SID - HDB" >> $post_deploy_log
echo "HANA Instance No. - 02" >> $post_deploy_log
echo "Application SID - S4H" >> $post_deploy_log
echo "ASCS Instance No. - 01" >> $post_deploy_log
echo "Dialog Instance No. - 00" >> $post_deploy_log
echo "Password - $default_password" >> $post_deploy_log
echo "----------------------------------------${nc}" >> $post_deploy_log

cleanup
log "${green}SAP S/4HANA FAA $s4h_version system deployment finished successfully${nc}"